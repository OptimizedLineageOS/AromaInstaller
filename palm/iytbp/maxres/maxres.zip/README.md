## Max Resolution for YouTube
[More details in support thread](https://forum.xda-developers.com/apps/magisk/module-max-resolution-youtube-unlock-2k-t3619821)  
Unlock 2K resolution on all devices and 4K on supported ones. Based on this [XDA article](https://www.xda-developers.com/how-to-watch-4k-youtube-videos-on-non-4k-phones/).

## Changelog
#### v1.1
- Updated Magisk module template to v4
#### v1
- Initial release
