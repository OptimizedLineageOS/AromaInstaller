## Systemless Xposed For SDK 25 (Android 7.1)
### Please install the modified [XposedInstaller](https://forum.xda-developers.com/attachment.php?attachmentid=4297539&d=1507562905)  

The APK is signed by my personal key, you might need to uninstall other versions before installing mine.

[More details in support thread](http://forum.xda-developers.com/showthread.php?t=3388268)

## Changelog

#### v88.0
- Update to official Xposed 88

#### v87.3
- Use workaround to prevent bootloop issues

#### v87.2
- Update to latest Magisk Module template
